package com.Rohan.journelApp.service;

import com.Rohan.journelApp.entity.JournelEntry;
import com.Rohan.journelApp.repository.JournelEntryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RestController;

@Component
public class JournelEntryService {

    @Autowired
    private JournelEntryRepository journelEntryRepository;

    public void saveEntry(JournelEntry journelEntry){
        journelEntryRepository.save(journelEntry);
    }


}




//controller --->services ---> repository
//          calls          calls