package com.Rohan.journelApp.controller;

import com.Rohan.journelApp.entity.JournelEntry;
import com.Rohan.journelApp.service.JournelEntryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;


@RestController  //
@RequestMapping("/journel")
public class JournelEntryControllerV2 {

    @Autowired
    private JournelEntryService journelEntryService;

    @GetMapping   //GET
    public List<JournelEntry> getAll(){
        return null;

    }

    @PostMapping  //POST
    public boolean createEntry(@RequestBody JournelEntry myEntry){
    journelEntryService.saveEntry(myEntry);
        return true;
    }

    @GetMapping("id/{myId}")
    public JournelEntry getJournelEntryById(@PathVariable Long myId){
        return null;

    }

    @DeleteMapping("id/{myId}")
    public JournelEntry deleteJournelEntryById(@PathVariable Long myId){
        return null;

    }

    @PutMapping("/id/{id}")
    public JournelEntry updateJournelById(@PathVariable Long id , @RequestBody JournelEntry myEntry){
       return null;
    }
}
